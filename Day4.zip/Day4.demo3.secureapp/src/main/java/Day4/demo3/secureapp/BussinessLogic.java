package Day4.demo3.secureapp;

import org.springframework.security.access.annotation.Secured;
import org.springframework.stereotype.Component;

@Component
public class BussinessLogic {

	@Secured(value = "ROLE_std")
	public void m1() {
		System.out.println("m1 invoked...");
	}
	@Secured("ROLE_admin")
	public void m2() {
		System.out.println("m2 invoked...");
	}
}
