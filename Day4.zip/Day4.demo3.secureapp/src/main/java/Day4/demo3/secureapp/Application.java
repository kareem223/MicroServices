package Day4.demo3.secureapp;

import javax.activation.DataSource;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ConfigurableApplicationContext;
import org.springframework.context.annotation.Bean;
import org.springframework.jdbc.datasource.DriverManagerDataSource;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.config.annotation.method.configuration.EnableGlobalMethodSecurity;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.context.SecurityContextImpl;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.provisioning.JdbcUserDetailsManager;

@SpringBootApplication
@EnableGlobalMethodSecurity(prePostEnabled = true, securedEnabled = true)

//prepost are the interceptors
//secureEnbaled will enable the @secured
public class Application {
	
	@Bean
	public DataSource ds() {
		return new DriverManagerDataSource("jdbc:hsqldb:hsql://localhost/", "SA", "");
	}


	public UserDetailsService userDetailsService() {
		
		JdbcUserDetailsManager mgr = new JdbcUserDetailsManager(ds());
		mgr.setUsersByUsernameQuery("select username, password, 'true' as  enabled from users where username=?");
		mgr.setAuthoritiesByUsernameQuery("select users.username, roles.role as role from users, roles where users.username = ?");
		return mgr;	

		/*
		 * List<UserDetails> listOfusers = new ArrayList<UserDetails>();
		 * listOfusers.add(User.withUsername("user1").password("{noop}pass1").roles(
		 * "std").build());
		 * listOfusers.add(User.withUsername("user2").password("{noop}pass2").roles(
		 * "admin").build());
		 * listOfusers.add(User.withUsername("user3").password("{noop}pass3").roles(
		 * "std", "admin").build()); return new InMemoryUserDetailsManager(listOfusers);
		 */

	}

	public static void main(String[] args) {
		ConfigurableApplicationContext ctx = SpringApplication.run(Application.class, args);
		SecurityContextImpl scimpl = new SecurityContextImpl();
		Authentication auth = new UsernamePasswordAuthenticationToken("user3", "pass3");
		scimpl.setAuthentication(auth);
		SecurityContextHolder.setContext(scimpl);

		BussinessLogic bl = ctx.getBean(BussinessLogic.class);

		try {
			bl.m1();
		} catch (Exception e) {
			System.out.println("m1 problem " + e);
		}

		try {
			bl.m2();
		} catch (Exception e) {
			System.out.println("m2 problem " + e);
		}
	}

}
