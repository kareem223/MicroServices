package Day1.demo1.Eureka.Client3;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;

@RestController
public class MyController3 {

	@Autowired
	private RestTemplate template;
	
	@GetMapping(value = "/")
	public String sayHello() {
		String url1="http://Client1";
		String url2="http://Client2";
		String str1=template.getForEntity(url1, String.class).getBody();
		String str2=template.getForEntity(url2, String.class).getBody();
		return str1+str2;
		
	}
}
