package Day1.demo1.Eureka.Client2.Day1.demo1.Eureka.Client2;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;

@RestController
public class Clinet2Controller {

	@Autowired
	private RestTemplate template;
	
	@GetMapping(value = "/")
	public String sayHello() {
		
		String url="http://Client1";
		String str=template.getForEntity(url, String.class).getBody();
		return "<h1>CLient2 coontroller</h1><h1>"+str+"</h1>";
	}
}
