package pl.piomin.services.gateway.model;

public enum ProductCategory {

	FOOD, ELECTRONICS, HEALTH;
	
}
