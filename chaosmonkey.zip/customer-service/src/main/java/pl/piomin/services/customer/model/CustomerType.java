package pl.piomin.services.customer.model;

public enum CustomerType {

	NORMAL, VIP;
	
}
