package pl.piomin.services.order.model;

public enum CustomerType {

	NORMAL, VIP;
	
}
