package pl.piomin.services.order.model;

public enum OrderStatus {

	NEW, ACCEPTED, REJECTED;
	
}
