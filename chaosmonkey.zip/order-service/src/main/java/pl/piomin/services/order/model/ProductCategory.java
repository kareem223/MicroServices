package pl.piomin.services.order.model;

public enum ProductCategory {

	FOOD, ELECTRONICS, HEALTH;
	
}
