package pl.piomin.services.performance;

public class ApiApplication {

	public static void main(String[] args) {
		System.out.println("Hello");
	}
	
}
