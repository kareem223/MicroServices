package pl.piomin.services.product.model;

public enum ProductCategory {

	FOOD, ELECTRONICS, HEALTH;
	
}
