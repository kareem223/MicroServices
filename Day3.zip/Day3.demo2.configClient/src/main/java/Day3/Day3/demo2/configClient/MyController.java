package Day3.Day3.demo2.configClient;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class MyController {
	@Value("${data:Hello default}")
	String data ;
	@GetMapping(value="/")
	public String showdetails() {
		return "<h1>Current data = " + data + "</h1>";
	}
}