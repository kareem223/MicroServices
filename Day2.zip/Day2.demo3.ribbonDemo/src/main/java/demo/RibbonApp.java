package demo;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.client.loadbalancer.LoadBalanced;
import org.springframework.context.annotation.Bean;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;

@SpringBootApplication
@RestController
public class RibbonApp {

	public static void main(String[] args) {
		SpringApplication.run(RibbonApp.class, args);
	}
	@Autowired
	RestTemplate template;
	
	@Bean
	@LoadBalanced
	public RestTemplate resttmp() {
		return new RestTemplate();
	}
	
	@GetMapping()
	public String showdata()
	{
		String str = template.getForEntity("http://simple/emps",String.class).getBody();
		return "<h1>Current Data</h1><h2>" + str + "</h2>"  ;
	}
}
