package Day2.Day2.demo6.FeignClient;

import java.util.List;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;

@FeignClient(name="mycontroller", url="http://localhost:8080")
public interface MyController {

	@GetMapping(value="/emps")
	public List<Emp> list();
	
	@GetMapping(value="/list")
	public List<Emp> list1();
}
