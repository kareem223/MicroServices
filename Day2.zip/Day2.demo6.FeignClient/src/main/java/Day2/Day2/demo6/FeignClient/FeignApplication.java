package Day2.Day2.demo6.FeignClient;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.openfeign.EnableFeignClients;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

@SpringBootApplication
@EnableFeignClients
@RestController
public class FeignApplication {

	public static void main(String[] args) {
		SpringApplication.run(FeignApplication.class, args);
	}
	@Autowired
	MyController mycon;
	@GetMapping(value="/show")
	public String showtable()
	{
		List<Emp> list = mycon.list();
		String str = "<table bgcolor='cyan' border='1'>";
		for (int i =0;i < list.size();i++) {
			str+= "<tr><td>" + list.get(i).getEmpno() + "</td><td>" + list.get(i).getEname() + 
					"</td><td>" + list.get(i).getSalary() + "</td></tr>";
		}
		str+= "</table>";
		return str;
	}
}
