package Day2.Day2.demo5.hystrixdemo;

import java.io.IOException;
import java.net.URL;

public class Test {

	public static void main(String[] args) throws IOException {
		// TODO Auto-generated method stub
		for(int i=0;i<50;i++) {
			URL url=new URL("http://localhost");
			url.getContent();
		}
			

	}

}
