package demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

@SpringBootApplication
@RestController
public class Application {

	public static void main(String[] args) {
		SpringApplication.run(Application.class, args);
	}
	@GetMapping(value="/")
	public String index() {
		return "<h1>IndexFile</h1><h1><a href='show'>Show </a><h1>";
	}
	@GetMapping(value="/show")
	public String index1() {
		return "<h1>Show Page </h1><h1><a href='/'>Home</a><h1>";
	}

}
