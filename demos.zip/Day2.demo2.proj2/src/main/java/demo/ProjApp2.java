package demo;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;

@SpringBootApplication
public class ProjApp2 {

	public static void main(String[] args) {
		SpringApplication.run(ProjApp2.class, args);
	}
	@Autowired
	EmpRepo repo;
	@Bean
	public String insert() {
			for (int i = 6;i <=10;i++) {
				Emp e = new Emp();
				e.setEmpno(i);
				e.setEname("Nameof"+i);
				e.setSalary(i*1000);
				repo.save(e);
			}
			return "success";
	}
}
