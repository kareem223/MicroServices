package demo;

import java.util.ArrayList;
import java.util.List;

import javax.sql.DataSource;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ConfigurableApplicationContext;
import org.springframework.context.annotation.Bean;
import org.springframework.jdbc.datasource.DriverManagerDataSource;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.config.annotation.authentication.configurers.provisioning.JdbcUserDetailsManagerConfigurer;
import org.springframework.security.config.annotation.method.configuration.EnableGlobalMethodSecurity;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.context.SecurityContextImpl;
import org.springframework.security.core.userdetails.User;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.provisioning.InMemoryUserDetailsManager;
import org.springframework.security.provisioning.JdbcUserDetailsManager;

@SpringBootApplication
@EnableGlobalMethodSecurity(prePostEnabled=true,securedEnabled=true)
public class SecureApp {

	
	@Bean
	public DataSource ds() {
		return new DriverManagerDataSource("jdbc:hsqldb:hsql://localhost/", "SA", "");
	}
	
	@Bean
    public UserDetailsService userDetailsService() {
		JdbcUserDetailsManager mgr = new JdbcUserDetailsManager(ds());
		
		mgr.setUsersByUsernameQuery("select username, password, 'true' as  enabled from users where username=?");
		mgr.setAuthoritiesByUsernameQuery("select users.username, roles.role as role from users, roles where users.username = ?");
		System.out.println(mgr.getUsersByUsernameQuery());
		return mgr;		
				
			/*List<UserDetails> list = new ArrayList<>();
	        list.add(User.withUsername("user1").password("{noop}pass1").roles("std").build());
	        list.add(User.withUsername("user2").password("{noop}pass2").roles("admin").build());
	        list.add(User.withUsername("user3").password("{noop}pass3").roles("std","admin").build());
	        return new InMemoryUserDetailsManager(list);
	        */
	    }
	
	
	public static void main(String[] args) {
		ConfigurableApplicationContext ctx = SpringApplication.run(SecureApp.class, args);
		SecurityContextImpl scimpl = new SecurityContextImpl();
		Authentication auth = new UsernamePasswordAuthenticationToken("user3", "pass3");
		scimpl.setAuthentication(auth);
		
		SecurityContextHolder.setContext(scimpl);

		BusinessLogic bl = ctx.getBean(BusinessLogic.class);
		try {
			bl.m1();
		} catch (Exception e) {
			System.out.println("m1 problem " + e);
		}
		
		try {
			bl.m2();
		} catch (Exception e) {
			System.out.println("m2 problem " + e);
		}
		try {
			bl.m3();
		} catch (Exception e) {
			System.out.println("m3 problem " + e);
		}
	}

}
