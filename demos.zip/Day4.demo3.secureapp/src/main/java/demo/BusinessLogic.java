package demo;

import org.springframework.security.access.annotation.Secured;
import org.springframework.stereotype.Component;

@Component
public class BusinessLogic {
	@Secured(value="ROLE_std")
	public void m1() {
		System.out.println("m1 invoked ....");
	}
	@Secured(value="ROLE_admin")
	public void m2() {
		System.out.println("m2 invoked ..");
	}
	public void m3() {
		System.out.println("m3 invoked ..");
	}
}
