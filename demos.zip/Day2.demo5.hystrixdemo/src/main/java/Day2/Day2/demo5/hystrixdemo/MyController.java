package Day2.Day2.demo5.hystrixdemo;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;

import com.netflix.hystrix.contrib.javanica.annotation.HystrixCommand;

@RestController
@RequestMapping(value="/")
public class MyController {

	@GetMapping()
	@HystrixCommand(commandKey="rc", groupKey="proj1", fallbackMethod="showdata_fall")
	public String showdata()
	{
		System.out.println("In showdata");
		RestTemplate template = new RestTemplate();
		String str = template.getForEntity("http://localhost:8080/emps",String.class).getBody();
		return "<h1>Current Data</h1><h2>" + str + "</h2>"  ;
	}

	public String showdata_fall()
	{
		System.out.println("*****in fallback");
		String str = "{ 'staticdata': 'cached info'	}";
		return "<h1>Current Data</h1><h2>" + str + "</h2>"  ;
	}

	@GetMapping(value="/tmp")
	@HystrixCommand(commandKey="rcslow", groupKey="proj1", fallbackMethod="showdata_fall1")
	public String showdata1()
	{
		System.out.println("In showdata");
		RestTemplate template = new RestTemplate();
		String str = template.getForEntity("http://localhost:8080/list",String.class).getBody();
		return "<h1>Current Data</h1><h2>" + str + "</h2>"  ;
	}

	public String showdata_fall1()
	{
		System.out.println("*****in fallback");
		String str = "{ 'staticdata': 'cached info'	}";
		return "<h1>Current Data</h1><h2>" + str + "</h2>"  ;
	}

	
}
