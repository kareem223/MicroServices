package demo;


import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;
@RestController
public class MyController {
	@GetMapping(value="/")
	public String index() {
		return "<h1>IndexFile</h1><h1><a href='show'>Show </a><h1><h1><a href='admin/m1'>admin m1 </a><h1><h1><a href='admin/m2'>Admin m2 </a><h1>";
	}
	@GetMapping(value="/show")
	public String index1() {
		return "<h1>Show Page </h1><h1><a href='/'>Home</a><h1>";
	}
	@GetMapping(value="/admin/m1")
	public String index2() {
		return "<h1>admin m1  Page </h1><h1><a href='/'>Home</a><h1>";
	}
	@GetMapping(value="/admin/m2")
	public String index3() {
		return "<h1>admin m2  Page </h1><h1><a href='/'>Home</a><h1>";
	}
	

}
