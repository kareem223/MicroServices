package demo;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;

@RestController
public class MyClient2Controller {
	
	@Autowired
	RestTemplate template ;
	@GetMapping
	public String get() {
		//String url ="http://localhost:8090";
		String url = "http://Client1";
	  String str = template.getForEntity(url, String.class).getBody();
		
		return "<h1>In MyClient2Controller</h1><h1>" + str + "</h1>" ;
	}
}
