package demo;

import java.util.List;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;
@FeignClient(name="myreqres", url="https://reqres.in/api/")
public interface ReqResController {

	@GetMapping(value="/users?page=1")
	public Details getdetails();
	
}
