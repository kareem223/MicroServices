package demo;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class ShowController {
	@Autowired
	MyController mycon;
	@Autowired
	ReqResController reqrescon;

	@GetMapping(value="/users")
	public String showtable1()
	{
		List<User> list = reqrescon.getdetails().getData();
		String str = "<table bgcolor='cyan' border='1'>";
		for (int i =0;i < list.size();i++) {
			str+= "<tr><td>" + list.get(i).getId() + "</td><td>" + list.get(i).getFirst_name() +" "+list.get(i).getLast_name()  + 
					"</td><td>" + list.get(i).getEmail() + 
					"</td><td><img src='" + list.get(i).getAvatar() + "'/></td></tr>";
		}
		str+= "</table>";
		return str;
	}

	
	@GetMapping(value="/show")
	public String showtable()
	{
		List<Emp> list = mycon.list();
		String str = "<table bgcolor='cyan' border='1'>";
		for (int i =0;i < list.size();i++) {
			str+= "<tr><td>" + list.get(i).getEmpno() + "</td><td>" + list.get(i).getEname() + 
					"</td><td>" + list.get(i).getSalary() + "</td></tr>";
		}
		str+= "</table>";
		return str;
	}
	
}
