package demo;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class MyController {

	@GetMapping(value="/")
	public String sayhello() {
		return "<h1 style='color:green;'>EurekaClient1- MyController-SayHello<h1>" ;
	}
}
