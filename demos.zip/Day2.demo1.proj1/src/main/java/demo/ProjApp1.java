package demo;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.domain.EntityScan;
import org.springframework.context.annotation.Bean;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;

@SpringBootApplication
@EnableJpaRepositories
@EntityScan(basePackages="demo")
public class ProjApp1 {

	public static void main(String[] args) {
		SpringApplication.run(ProjApp1.class, args);
	}
	@Autowired
	EmpRepo repo;
	@Bean
	public String insert() {
			for (int i = 1;i <=5;i++) {
				Emp e = new Emp();
				e.setEmpno(i);
				e.setEname("Nameof"+i);
				e.setSalary(i*1000);
				repo.save(e);
			}
			return "success";
	}
}
