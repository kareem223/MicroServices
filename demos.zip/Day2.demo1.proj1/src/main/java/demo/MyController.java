package demo;

import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping(value="/")
public class MyController {
	 private static final Logger LOG = Logger.getLogger(MyController.class.getName());
	    
	@Autowired
	EmpRepo repo;
	@GetMapping(value="/")
	public String index(){
	    System.out.println("in list");
	    String str =   "<h1><a href='emps' >Emps</a></h1>" +  "<h1><a href='list' >List</a></h1>";
	    return str;
}
	
	@GetMapping(value="/emps")
	public List<Emp> list(){
		    System.out.println("in list");
		    LOG.log(Level.INFO,"Something in proj1Mycontroller");
			return repo.findAll();
	}
	@GetMapping(value="/list")
	public List<Emp> list1(){
		    System.out.println("in list11");
		    try {
				Thread.sleep((int)(Math.random() * 10000));
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			return repo.findAll();
	}
	
}
